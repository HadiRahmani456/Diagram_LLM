from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
from sqlalchemy.orm import Session
from datetime import datetime, date
from app.services.ai_service import AIService, AIMode, DiagramType
from app.core.database import get_db
from app.api.v1.endpoints.auth import get_current_user
from app.models.user import User

router = APIRouter()
ai_service = AIService()


class DiagramRequest(BaseModel):
    text: str = Field(..., min_length=3, max_length=5000)
    mode: AIMode = AIMode.ONLINE
    diagram_type: Optional[DiagramType] = None
    language: str = "fa"


class DiagramResponse(BaseModel):
    success: bool
    mode: str
    engine: str
    diagram_type: str
    nodes: list
    edges: list
    mermaid_code: Optional[str] = None
    remaining_requests: Optional[int] = None


@router.post("/generate", response_model=DiagramResponse)
async def generate_diagram(
    request: DiagramRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    today = date.today()
    if current_user.last_request_date is None or current_user.last_request_date.date() != today:
        current_user.requests_today = 0
        current_user.last_request_date = datetime.now()

    # Only Groq consumes the user's daily Groq quota.
    if (
        request.mode == AIMode.ONLINE
        and not current_user.is_admin
        and current_user.requests_today >= current_user.daily_limit
    ):
        raise HTTPException(
            status_code=429,
            detail=f"محدودیت روزانه شما ({current_user.daily_limit} دیاگرام) به پایان رسیده. برای ادامه از Colab یا Local استفاده کنید."
        )

    try:
        result = await ai_service.analyze_text(
            text=request.text,
            mode=request.mode,
            diagram_type=request.diagram_type
        )

        if result.get("source") == "groq":
            current_user.requests_today += 1
            db.commit()

        remaining = (
            None
            if current_user.is_admin
            else max(0, current_user.daily_limit - current_user.requests_today)
        )

        diagram_type = result.get("suggested_type") or (
            request.diagram_type.value if request.diagram_type else "flowchart"
        )

        mermaid_code = generate_mermaid_code(
            nodes=result.get("nodes", []),
            edges=result.get("edges", []),
            diagram_type=diagram_type
        )

        return DiagramResponse(
            success=True,
            mode=request.mode.value,
            engine=result.get("source", request.mode.value),
            diagram_type=diagram_type,
            nodes=result.get("nodes", []),
            edges=result.get("edges", []),
            mermaid_code=mermaid_code,
            remaining_requests=remaining,
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        print(f"❌ Diagram generation error: {e}")
        raise HTTPException(status_code=500, detail="خطایی هنگام تولید دیاگرام رخ داد.")


def _safe_label(value: str, max_length: int = 80) -> str:
    value = str(value or "").replace('"', "'").replace("\n", " ").strip()
    return value[:max_length]


def generate_mermaid_code(nodes: list, edges: list, diagram_type: str) -> str:
    if not nodes:
        return "flowchart TD\n    A[داده‌ای برای نمایش وجود ندارد]"

    if diagram_type == "roadmap":
        code = "timeline\n    title نقشه راه\n"
        for i, node in enumerate(nodes, 1):
            label = _safe_label(node.get("label", "مرحله"), 90).replace(":", " - ")
            code += f"    {label}\n"
        return code

    if diagram_type == "gantt_chart":
        code = "gantt\n    title زمان‌بندی پروژه\n    dateFormat YYYY-MM-DD\n    axisFormat %d %b\n    section مراحل\n"
        from datetime import timedelta
        today = date.today()
        for i, node in enumerate(nodes, 1):
            label = _safe_label(node.get("label", f"وظیفه {i}"), 70).replace(":", " - ")
            start = today + timedelta(days=(i - 1) * 3)
            code += f"    {label} :a{i}, {start.isoformat()}, {i + 2}d\n"
        return code

    # Modern flowchart: shapes communicate semantic node types.
    code = "flowchart TD\n"
    for node in nodes:
        node_id = str(node.get("id", "n"))
        label = _safe_label(node.get("label", "مرحله"), 80)
        node_type = node.get("type", "process")

        if node_type == "start":
            code += f'    {node_id}(["{label}"])\n'
        elif node_type == "end":
            code += f'    {node_id}(["{label}"])\n'
        elif node_type == "decision":
            code += f'    {node_id}{{"{label}"}}\n'
        else:
            code += f'    {node_id}["{label}"]\n'

    for edge in edges:
        source = edge.get("from")
        target = edge.get("to")
        label = _safe_label(edge.get("label", ""), 25)
        if source and target:
            code += f'    {source} -->|{label}| {target}\n' if label else f'    {source} --> {target}\n'

    code += "\n    classDef startEnd fill:#312e81,stroke:#8b5cf6,color:#fff,stroke-width:2px;\n"
    code += "    classDef process fill:#172554,stroke:#3b82f6,color:#e0f2fe,stroke-width:1.5px;\n"
    code += "    classDef decision fill:#422006,stroke:#f59e0b,color:#fef3c7,stroke-width:2px;\n"

    start_end = [str(n.get("id")) for n in nodes if n.get("type") in {"start", "end"}]
    decisions = [str(n.get("id")) for n in nodes if n.get("type") == "decision"]
    processes = [str(n.get("id")) for n in nodes if n.get("type") not in {"start", "end", "decision"}]

    if start_end:
        code += f"    class {','.join(start_end)} startEnd;\n"
    if processes:
        code += f"    class {','.join(processes)} process;\n"
    if decisions:
        code += f"    class {','.join(decisions)} decision;\n"

    return code
